package com.example.assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

public class EventActivity extends AppCompatActivity {
    class EventSMSReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            assert msg != null;
            msg = msg.replace(";", ";|");

            StringTokenizer sT = new StringTokenizer(msg, ";");
            if (sT.countTokens() != 4) {
                Toast.makeText(context, "Count token should be 4", Toast.LENGTH_SHORT).show();
                return;
            }

            String eventName = "";
            String categoryID = "";
            String ticketsAvailableString = "";
            String isEventActiveString = "";

            try {
                eventName = sT.nextToken();

                categoryID = sT.nextToken();
                categoryID = categoryID.substring(1);

                ticketsAvailableString = sT.nextToken();
                ticketsAvailableString = ticketsAvailableString.substring(1);
                if (ticketsAvailableString.isEmpty()){
                    ticketsAvailableString = "1";
                }

                isEventActiveString = sT.nextToken();
                isEventActiveString = isEventActiveString.substring(1);
                if (isEventActiveString.isEmpty()){
                    isEventActiveString = "false";
                }

            } catch (Exception e) {
                Toast.makeText(context, "Missing Parameters or are not separated by semicolon", Toast.LENGTH_SHORT).show();
                return;
            }

            if(validBooleanString(isEventActiveString) && validMessageData(categoryID, eventName, ticketsAvailableString)){
                prefillEventData(categoryID, eventName, ticketsAvailableString, convertStringToBool(isEventActiveString));
            }
        }
    }

    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {

        private Context context;
        public MyNavigationListener(Context context) {
            this.context = context;
        }
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            int id = item.getItemId();

            if (id == R.id.viewAllCatNav) {
                redirectToListCategory();
            } else if (id == R.id.addCatNav) {
                redirectToNewCatForm();
            } else if (id == R.id.viewAllEventsNav) {
                redirectToListEvent();
            } else if (id == R.id.logoutNav) {
                logout();
            }
            drawerlayout.closeDrawers();
            return true;
        }

        public void redirectToListCategory(){
            Intent intent = new Intent(context, ListCategoryActivity.class);
            startActivity(intent);
        }

        public void redirectToListEvent(){
            Intent intent = new Intent(context, ListEventActivity.class);
            startActivity(intent);
        }

        public void redirectToNewCatForm(){
            Intent intent = new Intent(context, EventCategoryActivity.class);
            startActivity(intent);
        }

        public void logout() {
            Intent loginPageIntent = new Intent(context, LoginActivity.class);
            startActivity(loginPageIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        }
    }


    private EditText eventIdEditText, eventNameEditText, categoryIDEditText, ticketsAvailableEditText;
    private Switch isEventActiveSwitch;
    private Toolbar toolbar;
    private DrawerLayout drawerlayout;
    private NavigationView navigationView;
    private ArrayList<Event> listEvent = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_activity_dashboard);

        eventIdEditText = findViewById(R.id.eventIdEditText);
        eventNameEditText = findViewById(R.id.eventNameEditText);
        categoryIDEditText = findViewById(R.id.categoryIDEditText);
        ticketsAvailableEditText = findViewById(R.id.ticketsAvailableEditText);
        isEventActiveSwitch = findViewById(R.id.isEventActiveSwitch);

        EventSMSReceiver myBroadCastReceiver = new EventActivity.EventSMSReceiver();
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER_EVENT), RECEIVER_EXPORTED);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Assignment-2");

        drawerlayout = findViewById(R.id.drawer_layout_dashboard);
        navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerlayout, toolbar, R.string.open_nav_drawer, R.string.close_nav_drawer);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new MyNavigationListener(this));

        FloatingActionButton fab = findViewById(R.id.floatingActionButton);

//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSaveEventButtonClick(view);
            }
        });

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        FragmentListCategory fragment = new FragmentListCategory();
        transaction.replace(R.id.fragmentContainerViewEvent, fragment, "fragmentListCat");
        transaction.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.refreshOption) {
            refresh();
        } else if (itemId == R.id.clearEventFormOption) {
            clearEventForm();
        } else if (itemId == R.id.deleteAllCatOption) {
            deleteAllCategories();
        } else if (itemId == R.id.deleteAllEventsOption) {

        }
        return true;
    }

    public void refresh() {
        FragmentListCategory fragmentListCategory = (FragmentListCategory) getSupportFragmentManager().findFragmentById(R.id.fragmentContainerViewEvent);
        if (fragmentListCategory != null){
            fragmentListCategory.updateData();
        }
    }

    public void clearEventForm(){
        eventIdEditText.setText("");
        eventNameEditText.setText("");
        categoryIDEditText.setText("");
        ticketsAvailableEditText.setText("");
        isEventActiveSwitch.setChecked(false);
    }

    public void deleteAllCategories(){
        SharedPreferences sp = getSharedPreferences("EVENT_CATEGORY", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("EVENT_CATEGORY_DATA", "");
        editor.apply();
    }


    public void onSaveEventButtonClick(View view){
        String eventName = eventNameEditText.getText().toString();
        String categoryID = categoryIDEditText.getText().toString();
        String ticketsAvailableString = ticketsAvailableEditText.getText().toString();

        if (ticketsAvailableString.isEmpty()){
            ticketsAvailableString = "1";
            ticketsAvailableEditText.setText(ticketsAvailableString);
        }
        int ticketsAvailable = convertStringToInt(ticketsAvailableString);

        boolean isEventActive = isEventActiveSwitch.isChecked();

        if (validData(eventName, categoryID, ticketsAvailable)){
            String eventID = generateRandomEventID();
            displayEventID(eventID);
            saveEventToListEvent(eventID, eventName, categoryID, ticketsAvailable, isEventActive);
            saveListEventAsText();
//            Toast.makeText(this, String.format("Event saved: %s to %s", eventID, categoryID), Toast.LENGTH_SHORT).show();
            Snackbar.make(view, String.format("Event saved: %s to %s", eventID, categoryID), Snackbar.LENGTH_LONG)
                    .setAction("Undo", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!EventActivity.this.listEvent.isEmpty()) {
                                EventActivity.this.listEvent.remove(EventActivity.this.listEvent.size() - 1);
                                EventActivity.this.saveListEventAsText();
                            }
                            Toast.makeText(EventActivity.this, "Undo clicked", Toast.LENGTH_SHORT).show();
                        }
                    }).show();
        }
    }

    public void saveEventToListEvent(String eventID, String eventName, String categoryID, int ticketsAvailable, boolean isEventActive){
        SharedPreferences sharedPreferences = getSharedPreferences("EVENT", MODE_PRIVATE);
        String listEventString = sharedPreferences.getString("EVENT_DATA", "");
        Gson gson = new Gson();

        if (!listEventString.isEmpty()){
            Type type = new TypeToken<ArrayList<Event>>() {}.getType();
            ArrayList<Event> listEvent = gson.fromJson(listEventString, type);
            this.listEvent = listEvent;
        }

        this.listEvent.add(new Event(eventID, eventName, categoryID, ticketsAvailable, isEventActive));
    }

    private void saveListEventAsText(){
        Gson gson = new Gson();
        String listEventString = gson.toJson(this.listEvent);
        SharedPreferences sp = getSharedPreferences("EVENT", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("EVENT_DATA", listEventString);
        editor.apply();
    }

    public void displayEventID(String eventID){
        eventIdEditText.setText(eventID);
    }

    public void redirectToDashboardPage(View view){
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
    }

    private int convertStringToInt(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private boolean validData(String eventName, String categoryID, int ticketsAvailable){

        if (eventName.isEmpty()){
            Toast.makeText(this, "Event Name should not be Empty", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!validEventName(eventName)){
            Toast.makeText(this, "Event Name can only be AlphaNumeric", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!validCategoryId(categoryID)){
            Toast.makeText(this, "Category ID does not Exist", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (ticketsAvailable < 1) {
            Toast.makeText(this, "Tickets Available Number should be Positive", Toast.LENGTH_SHORT).show();
            return false;
        }
        incrementEventCount(categoryID);
        return true;
    }

    private void incrementEventCount(String categoryID){
        ArrayList<Category> listCategory =  retrieveListCategory();
        for (Category category : listCategory){
            if(category.getCategoryId().equalsIgnoreCase(categoryID)){
                Toast.makeText(this, "before " + category.getEventCount(), Toast.LENGTH_SHORT).show();
                category.setEventCount(category.getEventCount() + 1);
                Toast.makeText(this, "after " + category.getEventCount(), Toast.LENGTH_SHORT).show();
                break;
            }
        }

        FragmentListCategory fragmentListCategory = (FragmentListCategory) getSupportFragmentManager().findFragmentByTag("fragmentListCat");
        if (fragmentListCategory != null) {
            Toast.makeText(this, "fragment not null", Toast.LENGTH_SHORT).show();
            RecyclerAdapterCategory adapter = fragmentListCategory.recyclerAdapterCat;
            adapter.setData(listCategory);
            adapter.notifyDataSetChanged();
            saveListCategoryToSharedPreference(listCategory);
        }
        Toast.makeText(this, "fragment is null", Toast.LENGTH_SHORT).show();

    }

    private boolean validEventName(String eventName){
        if (eventName.matches("^[a-zA-Z0-9 ]+$")) {
            try{
                int validation = Integer.parseInt(eventName);
                return false;
            } catch(Exception e){
                return true;
            }
        }
        return false;
    }

    private boolean validCategoryId(String categoryID){
        ArrayList<Category> listCategory = retrieveListCategory();
        for (Category category : listCategory){
            if(category.getCategoryId().equalsIgnoreCase(categoryID)){
                return true;
            }
        }
        return false;
    }

    private ArrayList<Category> retrieveListCategory() {
        SharedPreferences sp = getSharedPreferences("EVENT_CATEGORY", Context.MODE_PRIVATE);
        String categoryData = sp.getString("EVENT_CATEGORY_DATA", "");
        Gson gson = new Gson();

        Type type = new TypeToken<ArrayList<Category>>() {}.getType();
        return gson.fromJson(categoryData, type);
    }

    private void saveListCategoryToSharedPreference(ArrayList<Category> listCategoy){
        Gson gson = new Gson();
        String listCategoryString = gson.toJson(listCategoy);
        SharedPreferences sp = getSharedPreferences("EVENT_CATEGORY", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("EVENT_CATEGORY_DATA", listCategoryString);
        editor.apply();
    }

    private String generateRandomEventID(){
        Random r = new Random();
        String fiveDigits = String.valueOf(r.nextInt(90000) + 10000);
        String str = "E" + generateRandomCharacter() + generateRandomCharacter() + "-" + fiveDigits;

        return str;
    }

    private char generateRandomCharacter(){
        Random r = new Random();
        return (char)(r.nextInt(26) + 'A');
    }

    private boolean validBooleanString(String str){
        if (str.isEmpty() || str.equalsIgnoreCase("TRUE") || (str.equalsIgnoreCase("FALSE"))){
            return true;
        }
        Toast.makeText(this, "Not a Boolean", Toast.LENGTH_SHORT).show();
        return false;
    }

    private boolean convertStringToBool(String str){
        if (str.equalsIgnoreCase("TRUE")) {
            return true;
        }
        return false;
    }
    private boolean validMessageData(String categoryID, String eventName, String ticketsAvailableString){
        int ticketsAvailable = 0;
        if (!ticketsAvailableString.isEmpty()){
            try {
                ticketsAvailable = Integer.parseInt(ticketsAvailableString);
                if (ticketsAvailable <= 0) {
                    Toast.makeText(this, "Tickets Available Number should be Positive", Toast.LENGTH_SHORT).show();
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        }

        if(categoryID.isEmpty()) {
            Toast.makeText(this, "Category ID should not be Empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (eventName.isEmpty() || eventName.matches("^.[^a-zA-Z0-9 ].$")) {
            Toast.makeText(this, "Event Name should not be Empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public void prefillEventData(String categoryID, String eventName, String ticketsAvailable, boolean isEventActive){
        EditText eventNameEditText = findViewById(R.id.eventNameEditText);
        EditText categoryIDEditText = findViewById(R.id.categoryIDEditText);
        EditText ticketsAvailableEditText = findViewById(R.id.ticketsAvailableEditText);
        Switch isEventActiveSwitch = findViewById(R.id.isEventActiveSwitch);

        eventNameEditText.setText(eventName);
        categoryIDEditText.setText(categoryID);
        ticketsAvailableEditText.setText(ticketsAvailable);
        isEventActiveSwitch.setChecked(isEventActive);
    }
}