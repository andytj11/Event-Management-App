package com.example.assignment1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class FragmentListCategory extends Fragment {

    public ArrayList<Category> listCategory = new ArrayList<>();
    public  RecyclerAdapterCategory recyclerAdapterCat;
    private RecyclerView recyclerViewCat;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recyclerAdapterCat = new RecyclerAdapterCategory();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_list_category, container, false);
        recyclerViewCat = fragmentView.findViewById(R.id.recyclerViewCat);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerViewCat.setLayoutManager(layoutManager);

        this.listCategory = retrieveListCategory();

        recyclerAdapterCat.setData(this.listCategory);
        recyclerViewCat.setAdapter(recyclerAdapterCat);

        return fragmentView;
    }

    private ArrayList<Category> retrieveListCategory() {
        SharedPreferences sp = getActivity().getSharedPreferences("EVENT_CATEGORY", Context.MODE_PRIVATE);
        String categoryData = sp.getString("EVENT_CATEGORY_DATA", "");
        Gson gson = new Gson();

        Type type = new TypeToken<ArrayList<Category>>() {}.getType();
        return gson.fromJson(categoryData, type);
    }

    public void updateData(){
        this.listCategory.clear();
        recyclerAdapterCat.categoryArrayList.clear();
        this.listCategory = retrieveListCategory();
        recyclerAdapterCat.setData(listCategory);
        recyclerAdapterCat.notifyDataSetChanged();
    }
}