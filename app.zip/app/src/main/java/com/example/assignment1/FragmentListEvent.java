package com.example.assignment1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class FragmentListEvent extends Fragment {

    public ArrayList<Event> listEvents = new ArrayList<>();
    private RecyclerAdapterEvent recyclerAdapterEvent;
    private RecyclerView recyclerViewEvent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recyclerAdapterEvent = new RecyclerAdapterEvent();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_list_event, container, false);

        recyclerViewEvent = fragmentView.findViewById(R.id.recyclerViewEvent);
        recyclerViewEvent.setLayoutManager(new LinearLayoutManager(getContext()));

        this.listEvents = retrieveListEvent();

        recyclerAdapterEvent.setData(this.listEvents);
        recyclerViewEvent.setAdapter(recyclerAdapterEvent);
        return fragmentView;
    }

    private ArrayList<Event> retrieveListEvent() {
        SharedPreferences sp = getActivity().getSharedPreferences("EVENT", Context.MODE_PRIVATE);
        String categoryData = sp.getString("EVENT_DATA", "");
        Gson gson = new Gson();

        Type type = new TypeToken<ArrayList<Event>>() {}.getType();
        return gson.fromJson(categoryData, type);
    }
}