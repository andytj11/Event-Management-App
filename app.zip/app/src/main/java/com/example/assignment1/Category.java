package com.example.assignment1;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class Category {

    private String categoryId;
    private String categoryName;
    private int eventCount;
    private boolean isActive;

    public Category(String categoryId, String categoryName, int eventCount, boolean isActive){
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.eventCount = eventCount;
        this.isActive = isActive;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getEventCount() {
        return eventCount;
    }

    public void setEventCount(int eventCount) {
        this.eventCount = eventCount;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @NonNull
    @Override
    public String toString() {
        return getCategoryId() + " | " + getCategoryName() + " | " +  getEventCount() + " | " + isActive();
    }
}
